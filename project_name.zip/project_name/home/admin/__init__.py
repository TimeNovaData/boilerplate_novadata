from .base_novadata_admin import BaseNovadataAdmin

__all__ = [
    "BaseNovadataAdmin",
]
