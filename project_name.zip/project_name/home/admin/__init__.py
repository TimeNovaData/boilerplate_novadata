from .custom_user_admin import CustomUserAdmin

__all__ = [
    CustomUserAdmin,
]
