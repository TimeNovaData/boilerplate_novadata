from .model_and_app_name import ModelAndAppNameMiddleware

__all__ = [
    ModelAndAppNameMiddleware,
]
