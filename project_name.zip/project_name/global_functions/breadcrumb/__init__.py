from .make_breadcrumb import make_breadcrumb

__all__ = [
    make_breadcrumb,
]
