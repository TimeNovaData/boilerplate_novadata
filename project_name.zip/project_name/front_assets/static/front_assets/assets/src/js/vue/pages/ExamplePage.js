export default{
  data(){
    return {

    }
  },
  delimiters: ["{*", "*}"], //delimitadores pra n conflitar com o django
}