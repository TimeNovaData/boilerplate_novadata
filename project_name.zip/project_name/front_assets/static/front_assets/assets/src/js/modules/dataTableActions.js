export default function dataTableActions() {
	document.querySelectorAll("table[js-dataTables]")
		?.forEach(t => {

		})
}